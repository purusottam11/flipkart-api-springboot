package com.purusottam.flipkartbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlipkartBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
