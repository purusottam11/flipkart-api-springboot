package com.purusottam.flipkartbackend.service.impl;

import com.purusottam.flipkartbackend.bean.AddressBean;
import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.ErrorCode;
import com.purusottam.flipkartbackend.model.Address;
import com.purusottam.flipkartbackend.repository.AddressRepository;
import com.purusottam.flipkartbackend.service.AddressService;
import com.purusottam.flipkartbackend.utils.CopyUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Log4j2
@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
    private AddressRepository addressRepository;

    @Override
    public AddressBean addAddress(AddressBean addressBean) {
        Boolean exist = addressRepository.findByName(addressBean.getName()).isPresent();
        if (exist) {
            throw new BusinessException(ErrorCode.ADDRESS_IS_EXIST);
        }
        Address address = new Address();
        CopyUtils.copySafe(addressBean, address);
        address = addressRepository.save(address);
        return addressBean;
    }

    @Override
    public AddressBean updateAddress(String addressId, AddressBean addressBean) {
        Address address = addressRepository.findById(addressId).orElseThrow(
                () -> new BusinessException(ErrorCode.ADDRESS_NOT_FOUND));
        CopyUtils.copySafe(addressBean, address);
        address = addressRepository.save(address);
        CopyUtils.copySafe(address, addressBean);
        return addressBean;
    }

    @Override
    public String deleteAddress(String addressId) {
        Boolean exists = addressRepository.findById(addressId).isPresent();
        if (!exists) {
            throw new BusinessException(ErrorCode.ADDRESS_NOT_FOUND);
        }
        addressRepository.deleteById(addressId);
        return "success";
    }

    @Override
    public AddressBean getAddress(String addressId) {
        Address address = addressRepository.findById(addressId).orElseThrow(
                () -> new BusinessException(ErrorCode.ADDRESS_NOT_FOUND));
        AddressBean addressBean = new AddressBean();
        CopyUtils.copySafe(address, addressBean);
        return addressBean;
    }

    @Override
    public List<AddressBean> getAddressByCustomerId(String customerId) {
        List<Address> addresses = addressRepository.findByCustomerId(customerId).get();
        List<AddressBean> list = new ArrayList<>();
        list = CopyUtils.copySafe(addresses, AddressBean.class);
        return list;
    }
}
