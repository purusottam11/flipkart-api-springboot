package com.purusottam.flipkartbackend.bean;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerBean {
    public enum Gender {
        MALE("Male "), FEMALE("Female");
        private String label;

        private Gender(String label) {
            this.label = label;
        }

        public String getLabel() {
            return label;
        }
    }

    private String firstName;
    private String lastName;
    @Email
    private String emailId;
    private String phoneNumber;
    private String imageUrl;
    private Gender gender;
    private String password;

}
