package com.purusottam.flipkartbackend.service;

import com.purusottam.flipkartbackend.bean.ChangePasswordBean;
import com.purusottam.flipkartbackend.bean.CustomerBean;
import com.purusottam.flipkartbackend.bean.SignInBean;

public interface CustomerService {

    CustomerBean signUp(CustomerBean customerBean);

    Boolean signIn(SignInBean signInBean);

    String changePassword(ChangePasswordBean changePasswordBean);

    CustomerBean updateCustomer(String customerId, CustomerBean customerBean);

    String deleteCustomer(String customerId);

    CustomerBean getCustomer(String customerId);

}
