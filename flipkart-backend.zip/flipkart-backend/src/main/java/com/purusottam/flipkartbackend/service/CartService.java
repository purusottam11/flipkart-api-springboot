package com.purusottam.flipkartbackend.service;

public interface CartService {

}
