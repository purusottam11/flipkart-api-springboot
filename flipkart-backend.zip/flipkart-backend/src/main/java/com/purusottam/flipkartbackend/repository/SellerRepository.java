package com.purusottam.flipkartbackend.repository;

import com.purusottam.flipkartbackend.bean.SellerBean;
import com.purusottam.flipkartbackend.model.Seller;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface SellerRepository extends MongoRepository<Seller, String> {
    Optional<SellerBean> findByEmail(String email);
}
