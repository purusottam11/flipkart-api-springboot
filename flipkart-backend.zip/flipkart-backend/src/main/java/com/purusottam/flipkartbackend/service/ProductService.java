package com.purusottam.flipkartbackend.service;

import com.purusottam.flipkartbackend.bean.ProductBean;

import java.util.List;

public interface ProductService {

    ProductBean addProduct(ProductBean productBean);

    ProductBean updateProduct(String productId, ProductBean productBean);

    ProductBean getProduct(String productId);

    String deleteProduct(String productId);

    List<ProductBean> getProductByBrandId(String brandId);

    List<ProductBean> getProductByCategoryId(String categoryId);

}
