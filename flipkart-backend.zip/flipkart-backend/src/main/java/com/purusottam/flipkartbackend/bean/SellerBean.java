package com.purusottam.flipkartbackend.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SellerBean {

    private String sellerName;
    private String email;
    private String phoneNumber;
    private String imageUrl;
    private String password;
    private String state;
    private String city;
    private String address;
    private Integer pinCode;
    // Optional
    private String website;
}
