package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.bean.BrandBean;
import com.purusottam.flipkartbackend.service.BrandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/brand")
public class BrandController {

    @Autowired
    private BrandService brandService;

    @PostMapping("/addBrand")
    public ResponseEntity<BrandBean> addBrand(@RequestBody BrandBean brandBean) {
        return new ResponseEntity<>(brandService.addBrand(brandBean), HttpStatus.CREATED);
    }

    @PutMapping("/updateBrand/{brandId}")
    public ResponseEntity<BrandBean> updateBrand(@PathVariable String brandId, @RequestBody BrandBean brandBean) {
        return new ResponseEntity<>(brandService.updateBrand(brandId, brandBean), HttpStatus.OK);
    }

    @DeleteMapping("/deleteBrand/{brandId}")
    public ResponseEntity<String> deleteBrand(@PathVariable String brandId) {
        return new ResponseEntity<>(brandService.deleteBrand(brandId), HttpStatus.OK);
    }

}
