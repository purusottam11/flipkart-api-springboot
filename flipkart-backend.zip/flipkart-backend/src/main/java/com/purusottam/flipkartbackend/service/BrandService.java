package com.purusottam.flipkartbackend.service;

import com.purusottam.flipkartbackend.bean.BrandBean;

public interface BrandService {

    BrandBean addBrand(BrandBean brandBean);

    BrandBean updateBrand(String brandId, BrandBean brandBean);

    String deleteBrand(String brandId);

}
