package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.CustomError;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionAdvice {

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<CustomError> mapException(BusinessException ex) {
        CustomError error = new CustomError(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
        return new ResponseEntity<CustomError>(error, HttpStatus.valueOf(error.getErrorCode()));
    }
}
