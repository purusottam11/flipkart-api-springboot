package com.purusottam.flipkartbackend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document
public class Inventory {

    public enum Availability {
        AVAILABLE("available"), OUT_OF_STUCK("Out of stuck");
        private String label;

        private Availability(String label) {
            this.label = label;
        }

        public String getLabel() {
            return label;
        }
    }
    @Id
    private String inventoryId;
    private String productId;
    private Integer count;
    private Availability availability;
}
