package com.purusottam.flipkartbackend.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartResponseBean {
    private String cartId;
    private String customerId;
    private String productId;
    private Integer quantity;
    // Price total Item
    private Integer price;
    private Instant timestamp;
}
