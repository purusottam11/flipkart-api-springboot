package com.purusottam.flipkartbackend.repository;

import com.purusottam.flipkartbackend.model.Brand;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface BrandRepository extends MongoRepository<Brand, String> {
    Optional<Brand> findByBrandName(String brandName);
}
