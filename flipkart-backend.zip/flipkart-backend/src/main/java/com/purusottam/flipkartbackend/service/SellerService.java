package com.purusottam.flipkartbackend.service;

import com.purusottam.flipkartbackend.bean.SellerBean;

public interface SellerService {

    SellerBean addSeller(SellerBean sellerBean);

    SellerBean updateSeller(String sellerId, SellerBean sellerBean);

    String deleteSeller(String sellerId);

    SellerBean getSeller(String sellerId);

}
