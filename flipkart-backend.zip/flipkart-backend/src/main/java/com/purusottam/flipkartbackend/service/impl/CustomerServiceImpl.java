package com.purusottam.flipkartbackend.service.impl;

import com.purusottam.flipkartbackend.bean.ChangePasswordBean;
import com.purusottam.flipkartbackend.bean.CustomerBean;
import com.purusottam.flipkartbackend.bean.SignInBean;
import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.ErrorCode;
import com.purusottam.flipkartbackend.model.Customer;
import com.purusottam.flipkartbackend.repository.CustomerRepository;
import com.purusottam.flipkartbackend.service.CustomerService;
import com.purusottam.flipkartbackend.utils.CopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public CustomerBean signUp(CustomerBean customerBean) {
        customerRepository.findByEmailId(customerBean.getEmailId()).ifPresent(i -> {
            throw new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND);
        });
        String password = customerBean.getPassword();
        String pattern = "^[a-zA-Z0-9]+$";
        if (!password.matches(pattern)) {
            throw new BusinessException("Try a different password");
        }
        Customer customer = new Customer();
        CopyUtils.copySafe(customerBean, customer);
        customer = customerRepository.save(customer);
        return customerBean;
    }

    @Override
    public Boolean signIn(SignInBean signInBean) {
        Customer customer = customerRepository.findByEmailId(signInBean.getEmailId()).orElseThrow(
                () -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND));
        if (!customer.getPassword().equals(signInBean.getPassword())) {
            return false;
        }
        return true;
    }

    @Override
    public String changePassword(ChangePasswordBean changePasswordBean) {
        Customer customer = customerRepository.findByEmailId(changePasswordBean.getEmailId()).orElseThrow(
                () -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND));
        if (!customer.getPassword().equals(changePasswordBean.getOldPassword())) {
            throw new BusinessException("Old Password does not match try Again ... !");
        } else {
            String password = changePasswordBean.getNewPassword();
            String pattern = "^[a-zA-Z0-9]+$";
            if (!password.matches(pattern)) {
                throw new BusinessException("Try a different new password ... !");
            }
        }
        customer.setPassword(changePasswordBean.getNewPassword());
        customer = customerRepository.save(customer);
        return "Success";
    }

    @Override
    public CustomerBean updateCustomer(String customerId, CustomerBean customerBean) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                () -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND));
        CopyUtils.copySafe(customerBean, customer);
        customer = customerRepository.save(customer);
        CopyUtils.copySafe(customer, customerBean);
        return customerBean;
    }

    @Override
    public String deleteCustomer(String customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                () -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND));
        customerRepository.deleteById(customerId);
        return "Success";
    }

    @Override
    public CustomerBean getCustomer(String customerId) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(
                () -> new BusinessException(ErrorCode.CUSTOMER_NOT_FOUND));
        CustomerBean customerBean = new CustomerBean();
        CopyUtils.copySafe(customer, customerBean);
        return customerBean;
    }
}
