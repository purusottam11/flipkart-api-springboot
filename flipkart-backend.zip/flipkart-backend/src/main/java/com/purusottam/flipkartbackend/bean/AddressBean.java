package com.purusottam.flipkartbackend.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressBean {

    private String name;
    private String address1;
    private Integer pinCode;
    private String state;
    private String city;
    // Optional
    private String landmark;
    private String customerId;

}
