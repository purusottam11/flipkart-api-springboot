package com.purusottam.flipkartbackend.service.impl;

import com.purusottam.flipkartbackend.bean.SellerBean;
import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.ErrorCode;
import com.purusottam.flipkartbackend.model.Seller;
import com.purusottam.flipkartbackend.repository.SellerRepository;
import com.purusottam.flipkartbackend.service.SellerService;
import com.purusottam.flipkartbackend.utils.CopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SellerServiceImpl implements SellerService {

    @Autowired
    private SellerRepository sellerRepository;

    @Override
    public SellerBean addSeller(SellerBean sellerBean) {
        Boolean exists = sellerRepository.findByEmail(sellerBean.getEmail()).isPresent();
        if (exists) {
            throw new BusinessException(ErrorCode.SELLER_IS_EXIST);
        }
        Seller seller = new Seller();
        CopyUtils.copySafe(sellerBean, seller);
        seller = sellerRepository.save(seller);
        return sellerBean;
    }

    @Override
    public SellerBean updateSeller(String sellerId, SellerBean sellerBean) {
        Seller seller = sellerRepository.findById(sellerId).orElseThrow(
                () -> new BusinessException(ErrorCode.SELLER_NOT_FOUND));

        CopyUtils.copySafe(sellerBean, seller);
        seller = sellerRepository.save(seller);
        CopyUtils.copySafe(seller, sellerBean);
        return sellerBean;
    }

    @Override
    public String deleteSeller(String sellerId) {
        Boolean exists = sellerRepository.existsById(sellerId);
        if (!exists) {
            throw new BusinessException(ErrorCode.SELLER_NOT_FOUND);
        }
        sellerRepository.deleteById(sellerId);
        return "Success";
    }

    @Override
    public SellerBean getSeller(String sellerId) {
        Seller seller = sellerRepository.findById(sellerId).orElseThrow(
                () -> new BusinessException(ErrorCode.SELLER_NOT_FOUND));
        SellerBean sellerBean = new SellerBean();
        CopyUtils.copySafe(seller, sellerBean);
        return sellerBean;
    }
}
