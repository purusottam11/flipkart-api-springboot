package com.purusottam.flipkartbackend.exception;


public class ErrorCode {

    public static final String CUSTOMER_NOT_FOUND = "Customer not Found ... ";
    public static final String CUSTOMER_IS_EXIST = "Customer is Exist ... ";
    public static final String ADDRESS_IS_EXIST = "Address is Exist ... ";
    public static final String ADDRESS_NOT_FOUND = "Address not found ...";
    public static final String SELLER_IS_EXIST = "Seller is Exist ... ";
    public static final String SELLER_NOT_FOUND = "Seller not found ...";
    public static final String BRAND_IS_EXIST = "Brand is Exist ... ";
    public static final String BRAND_NOT_FOUND = "Brand not found ...";
    public static final String PRODUCT_IS_EXIST = "Product is Exist ... ";
    public static final String PRODUCT_NOT_FOUND = "Product not found ...";
    public static final String CATEGORY_IS_EXIST = "Category is Exist ... ";
    public static final String CATEGORY_NOT_FOUND = "Category not found ...";


}
