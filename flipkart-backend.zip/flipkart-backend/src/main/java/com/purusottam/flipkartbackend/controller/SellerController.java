package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.bean.SellerBean;
import com.purusottam.flipkartbackend.service.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;

@RestController
@RequestMapping("/seller")
public class SellerController {

    @Autowired
    private SellerService sellerService;

    @PostMapping("/addSeller")
    public ResponseEntity<SellerBean> addSeller(@RequestBody SellerBean sellerBean) {
        return new ResponseEntity<>(sellerService.addSeller(sellerBean), HttpStatus.CREATED);
    }

    @PutMapping("/updateSeller/{sellerId}")
    public ResponseEntity<SellerBean> updateSeller(@PathVariable String sellerId, @RequestBody SellerBean sellerBean) {
        return new ResponseEntity<>(sellerService.updateSeller(sellerId, sellerBean), HttpStatus.OK);
    }

    @GetMapping("/getSeller/{sellerId}")
    public ResponseEntity<SellerBean> getSeller(@PathParam("sellerId") String sellerId) {
        return new ResponseEntity<>(sellerService.getSeller(sellerId), HttpStatus.OK);
    }

    @DeleteMapping("/deleteSeller/{sellerId}")
    public ResponseEntity<String> deleteSeller(@PathVariable String sellerId) {
        return new ResponseEntity<>(sellerService.deleteSeller(sellerId), HttpStatus.OK);
    }
}
