package com.purusottam.flipkartbackend.utils;

import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface SampleProductRepository extends MongoRepository<SampleProduct, String> {

    @Query("{'title' : ?0}")
    List<SampleProduct> findProductByTitle(String title);

    @Query(value = "{'title': {$regex : ?0}}")
    List<SampleProduct> findByTitleRegex(String regexString, Pageable pageable);

    List<SampleProduct> findByTitleLikeIgnoreCase(String title);

    @Query(value = "{$or:[{name:{$regex:?0,$options:'i'}},{email:{$regex:?0,$options:'i'}}]}")
    List<SampleProduct> findAllByFreeTextSearch(String keyword);
}
