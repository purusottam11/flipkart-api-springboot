package com.purusottam.flipkartbackend.service.impl;

import com.purusottam.flipkartbackend.bean.ProductBean;
import com.purusottam.flipkartbackend.esmodel.ProductSearchModel;
import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.ErrorCode;
import com.purusottam.flipkartbackend.model.Brand;
import com.purusottam.flipkartbackend.model.Category;
import com.purusottam.flipkartbackend.model.Product;
import com.purusottam.flipkartbackend.repository.BrandRepository;
import com.purusottam.flipkartbackend.repository.CategoryRepository;
import com.purusottam.flipkartbackend.repository.ProductRepository;
import com.purusottam.flipkartbackend.repository.ProductSearchModelRepository;
import com.purusottam.flipkartbackend.service.ProductService;
import com.purusottam.flipkartbackend.utils.CopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private BrandRepository brandRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ProductSearchModelRepository productSearchModelRepository;

    @Override
    @Transactional
    public ProductBean addProduct(ProductBean productBean) {
        Brand brand = brandRepository.findById(productBean.getBrandId()).orElseThrow(
                () -> new BusinessException(ErrorCode.BRAND_NOT_FOUND));
        Category category = categoryRepository.findById(productBean.getCategoryId()).orElseThrow(
                () -> new BusinessException(ErrorCode.CATEGORY_NOT_FOUND));
        if (productRepository.findByProductName(productBean.getProductName()).isPresent()) {
            throw new BusinessException(ErrorCode.PRODUCT_IS_EXIST);
        }
        Product product = new Product();
        CopyUtils.copySafe(productBean, product);
        productRepository.save(product);
        return productBean;
    }

    @Override
    public ProductBean updateProduct(String productId, ProductBean productBean) {
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new BusinessException(ErrorCode.PRODUCT_NOT_FOUND));
        if (productBean.getBrandId() != null) {
            if (!brandRepository.existsById(productBean.getBrandId())) {
                throw new BusinessException(ErrorCode.BRAND_NOT_FOUND);
            }
        }
        if (productBean.getCategoryId() != null) {
            if (!categoryRepository.existsById(productBean.getCategoryId())) {
                throw new BusinessException(ErrorCode.CATEGORY_NOT_FOUND);
            }
        }
        CopyUtils.copySafe(productBean, product);
        product = productRepository.save(product);

        return null;
    }

    @Override
    public ProductBean getProduct(String productId) {
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new BusinessException(ErrorCode.PRODUCT_NOT_FOUND));
        ProductBean productBean = new ProductBean();
        CopyUtils.copySafe(product, productBean);
        return productBean;
    }

    @Override
    public String deleteProduct(String productId) {
        Product product = productRepository.findById(productId).orElseThrow(
                () -> new BusinessException(ErrorCode.PRODUCT_NOT_FOUND));
        productRepository.deleteById(productId);
        return "success";
    }

    @Override
    public List<ProductBean> getProductByBrandId(String brandId) {
        List<Product> list = (List<Product>) productRepository.findByBrandId(brandId).get();
        List<ProductBean> result = CopyUtils.copySafe(list, ProductBean.class);
        return result;
    }

    @Override
    public List<ProductBean> getProductByCategoryId(String categoryId) {
        List<Product> list = (List<Product>) productRepository.findByCategoryId(categoryId).get();
        List<ProductBean> result = CopyUtils.copySafe(list, ProductBean.class);
        return result;
    }
}
