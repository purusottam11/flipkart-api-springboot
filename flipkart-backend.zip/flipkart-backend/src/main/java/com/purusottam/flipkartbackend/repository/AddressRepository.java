package com.purusottam.flipkartbackend.repository;

import com.purusottam.flipkartbackend.model.Address;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface AddressRepository extends MongoRepository<Address, String> {

    Optional<Address> findByName(String name);

    Optional<List<Address>> findByCustomerId(String customerId);

}
