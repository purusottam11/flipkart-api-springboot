package com.purusottam.flipkartbackend.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponseBean extends Throwable {

    private String errorMessage;
    private Integer errorCode;

}
