package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.bean.ChangePasswordBean;
import com.purusottam.flipkartbackend.bean.CustomerBean;
import com.purusottam.flipkartbackend.bean.SignInBean;
import com.purusottam.flipkartbackend.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/signUp")
    public ResponseEntity<CustomerBean> sineUp(@RequestBody CustomerBean customerBean) {
        return new ResponseEntity<>(customerService.signUp(customerBean), HttpStatus.CREATED);
    }

    @GetMapping("/signIn")
    public ResponseEntity<Boolean> signIn(@PathParam("emailId") String emailId, @PathParam("password") String password) {
        return new ResponseEntity<>(customerService.signIn(new SignInBean(emailId, password)), HttpStatus.OK);
    }

    @PutMapping("/changePassword")
    public ResponseEntity<String> changePassword(@RequestBody ChangePasswordBean changePasswordBean) {
        return new ResponseEntity<>(customerService.changePassword(changePasswordBean), HttpStatus.OK);
    }

    @DeleteMapping("/deleteCustomer/{customerId}")
    public ResponseEntity<String> deleteCustomer(@PathVariable String customerId) {
        return new ResponseEntity<>(customerService.deleteCustomer(customerId), HttpStatus.OK);
    }

    @GetMapping("/getCustomer")
    public ResponseEntity<CustomerBean> getCustomer(@PathParam("customerId") String customerId) {
        return new ResponseEntity<>(customerService.getCustomer(customerId), HttpStatus.OK);
    }
}
