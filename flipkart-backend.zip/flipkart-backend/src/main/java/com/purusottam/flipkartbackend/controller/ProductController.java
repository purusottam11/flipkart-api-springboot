package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.bean.ProductBean;
import com.purusottam.flipkartbackend.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/addProduct")
    public ResponseEntity<ProductBean> addProduct(@RequestBody ProductBean productBean) {
        return new ResponseEntity<>(productService.addProduct(productBean), HttpStatus.CREATED);
    }


    @PutMapping("/updateProduct/{productId}")
    public ResponseEntity<ProductBean> updateProduct(@PathVariable String productId, @RequestBody ProductBean productBean) {
        return new ResponseEntity<>(productService.updateProduct(productId, productBean), HttpStatus.OK);
    }

    @GetMapping("/getProduct/{productId}")
    public ResponseEntity<ProductBean> getProduct(@PathVariable String productId) {
        return new ResponseEntity<>(productService.getProduct(productId), HttpStatus.OK);
    }

    @DeleteMapping("/deleteProduct/{productId}")
    public ResponseEntity<String> deleteProduct(@PathVariable String productId) {
        return new ResponseEntity<>(productService.deleteProduct(productId), HttpStatus.OK);
    }

    @GetMapping("/getProductByBrandId}")
    public ResponseEntity<List<ProductBean>> getProductsByBrandId(@PathParam("brandId") String brandId) {
        return new ResponseEntity<>(productService.getProductByBrandId(brandId), HttpStatus.OK);
    }

    @GetMapping("/getProductsByCategoryId")
    public ResponseEntity<List<ProductBean>> getProductsByCategoryId(@PathParam("categoryId") String categoryId) {
        return new ResponseEntity<>(productService.getProductByCategoryId(categoryId), HttpStatus.OK);
    }

}
