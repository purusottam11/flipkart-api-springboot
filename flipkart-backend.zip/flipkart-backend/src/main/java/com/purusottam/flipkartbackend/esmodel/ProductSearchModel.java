package com.purusottam.flipkartbackend.esmodel;

import com.purusottam.flipkartbackend.model.Brand;
import com.purusottam.flipkartbackend.model.Category;
import com.purusottam.flipkartbackend.model.Product;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(indexName = "product-search-model")
public class ProductSearchModel {
    @Id
    private String id;
    private Product product;
    private Brand brand;
    private Category category;
}
