package com.purusottam.flipkartbackend.service.impl;

import com.purusottam.flipkartbackend.bean.BrandBean;
import com.purusottam.flipkartbackend.exception.BusinessException;
import com.purusottam.flipkartbackend.exception.ErrorCode;
import com.purusottam.flipkartbackend.model.Brand;
import com.purusottam.flipkartbackend.repository.BrandRepository;
import com.purusottam.flipkartbackend.service.BrandService;
import com.purusottam.flipkartbackend.utils.CopyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BrandServiceImpl implements BrandService {

    @Autowired
    private BrandRepository brandRepository;

    @Override
    public BrandBean addBrand(BrandBean brandBean) {
        Boolean exist = brandRepository.findByBrandName(brandBean.getBrandName()).isPresent();
        if (exist) {
            throw new BusinessException(ErrorCode.BRAND_IS_EXIST);
        }
        Brand brand = new Brand();
        CopyUtils.copySafe(brandBean, brand);
        brand = brandRepository.save(brand);
        return brandBean;
    }

    @Override
    public BrandBean updateBrand(String brandId, BrandBean brandBean) {
        Brand brand = brandRepository.findById(brandId).orElseThrow(
                () -> new BusinessException(ErrorCode.BRAND_NOT_FOUND));
        CopyUtils.copySafe(brandBean, brand);
        brand = brandRepository.save(brand);
        CopyUtils.copySafe(brand, brandBean);
        return brandBean;
    }

    @Override
    public String deleteBrand(String brandId) {
        Boolean exist = brandRepository.existsById(brandId);
        if (!exist) {
            throw new BusinessException(ErrorCode.BRAND_NOT_FOUND);
        }
        brandRepository.deleteById(brandId);
        return "success";
    }
}
