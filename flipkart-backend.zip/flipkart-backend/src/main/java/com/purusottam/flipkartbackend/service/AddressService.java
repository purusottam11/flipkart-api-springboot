package com.purusottam.flipkartbackend.service;

import com.purusottam.flipkartbackend.bean.AddressBean;

import java.util.List;

public interface AddressService {

    AddressBean addAddress(AddressBean addressBean);

    AddressBean updateAddress(String addressId, AddressBean addressBean);

    String deleteAddress(String addressId);

    AddressBean getAddress(String addressId);

    List<AddressBean> getAddressByCustomerId(String customerId);

}
