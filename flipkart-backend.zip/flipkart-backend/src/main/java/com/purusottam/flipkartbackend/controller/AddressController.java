package com.purusottam.flipkartbackend.controller;

import com.purusottam.flipkartbackend.bean.AddressBean;
import com.purusottam.flipkartbackend.service.AddressService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;


@RestController
@RequestMapping("/address")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @PostMapping("/addAddress")
    public ResponseEntity<AddressBean> addAddress(@RequestBody AddressBean addressBean) {
        return new ResponseEntity<>(addressService.addAddress(addressBean), HttpStatus.CREATED);
    }

    @PutMapping("/updateAddress/{addressId}")
    public ResponseEntity<AddressBean> updateAddress(@PathVariable String addressId, @RequestBody AddressBean addressBean) {
        return new ResponseEntity<>(addressService.updateAddress(addressId, addressBean), HttpStatus.OK);
    }

    @DeleteMapping("/deleteAddress/{addressId}")
    public ResponseEntity<String> deleteAddress(@PathVariable String addressId) {
        return new ResponseEntity<>(addressService.deleteAddress(addressId), HttpStatus.OK);
    }

    @GetMapping("/getAddress")
    public ResponseEntity<AddressBean> getAddress(@PathParam("addressId") String addressId) {
        return new ResponseEntity<>(addressService.getAddress(addressId), HttpStatus.OK);
    }

    @GetMapping("/getAddressesByCustomerId")
    public ResponseEntity<List<AddressBean>> getAddressesByCustomerId(@PathParam("customerId") String customerId) {
        return new ResponseEntity<>(addressService.getAddressByCustomerId(customerId), HttpStatus.OK);
    }

}
