package com.purusottam.flipkartbackend.bean;

import java.time.Instant;

public class CartRequestBean {
    private String customerId;
    private String productId;
    private Integer quantity;
    // Price total Item
    private Integer price;
    private Instant timestamp;
}
