package com.purusottam.flipkartbackend.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductBean {
    private String productName;
    private String productUrl;
    // Primary key from the Category table
    private String categoryId;
    private Integer retailPrice;
    private Integer discountPrice;
    private String description;
    private Double averageRating;
    // primary key from the Brand table
    private String brandId;
}
