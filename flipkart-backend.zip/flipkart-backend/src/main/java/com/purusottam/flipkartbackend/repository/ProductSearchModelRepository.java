package com.purusottam.flipkartbackend.repository;

import com.purusottam.flipkartbackend.esmodel.ProductSearchModel;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface ProductSearchModelRepository extends ElasticsearchRepository<ProductSearchModel, String> {
}
