package com.purusottam.flipkartbackend.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.websocket.server.PathParam;
import java.util.List;

@RestController
@RequestMapping("/sample-search")
public class SearchService {
    @Autowired
    private SampleProductRepository sampleProductRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    @GetMapping("/products")
    public List<SampleProduct> getSampleProducts() {
        return sampleProductRepository.findAll();
    }

    @GetMapping("/searchByTitle")
    public List<SampleProduct> searchByTitle(@PathParam("title") String title) {
        return sampleProductRepository.findProductByTitle(title);
    }

    @GetMapping("/searchByTitleLike")
    public List<SampleProduct> searchByTitleLike(@PathParam("title") String title) {
//        Query query = new Query();
//        query.addCriteria(Criteria.where("title").regex("^" + title));
//        List<SampleProduct> products = mongoTemplate.find(query, SampleProduct.class);
//        return products;
        return sampleProductRepository.findByTitleRegex(title,PageRequest.of(0,2));
        //return sampleProductRepository.findByTitleLikeIgnoreCase(title);
    }

    @GetMapping("/getProductByPriceRange")
    public List<SampleProduct> getProductByPriceRange(@PathParam("startPrice") Double startPrice, @PathParam("endValue") Double endValue) {
        Query query = new Query();
        query.addCriteria(Criteria.where("price").gt(startPrice).andOperator(Criteria.where("price").lt(endValue)));//.addCriteria(Criteria.where("price").lt("endValue"));
        List<SampleProduct> products = mongoTemplate.find(query, SampleProduct.class);
        return products;
    }

    @GetMapping("/getSampleSearch")
    public List<SampleProduct> getSampleSearch(@PathParam("title") String title, @PathParam("pageNumber") Integer pageNumber, @PathParam("pageSize") Integer pageSize) {
        Query query = new Query();
        query.addCriteria(Criteria.where("title").regex(".*" + title + ".*"));
        query.with(PageRequest.of(pageNumber,pageSize));
        List<SampleProduct> products = mongoTemplate.find(query, SampleProduct.class);
        return products;

    }
}